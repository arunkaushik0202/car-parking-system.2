// JavaScript only collects input, sends it to the Java backend, and shows the result.
// NO parking rules and NO charge calculation are written here.
const API = "http://localhost:8080/api";

// Send a POST request with form-style parameters, return the JSON reply.
async function post(path, params) {
  const res = await fetch(API + path, { method: "POST", body: new URLSearchParams(params) });
  return res.json();
}

function showMessage(id, text, ok) {
  const el = document.getElementById(id);
  el.textContent = text;                       // textContent is safe (no HTML injection)
  el.className = "msg " + (ok ? "ok" : "err");
}

function val(id) { return document.getElementById(id).value; }

// ---------- DASHBOARD ----------
async function loadDashboard() {
  try {
    const d = await (await fetch(API + "/dashboard")).json();
    document.getElementById("totalSlots").textContent = d.totalSlots;
    document.getElementById("availableSlots").textContent = d.availableSlots;
    document.getElementById("occupiedSlots").textContent = d.occupiedSlots;
    document.getElementById("totalVehicles").textContent = d.totalVehicles;
    document.getElementById("todayRevenue").textContent = "₹" + d.todayRevenue;
    document.getElementById("rules").textContent =
      `First ${d.allowedHours} hours = ₹${d.baseCharge}, then ₹${d.extraRate} per extra hour (part of an hour counts as a full hour)`;

    const box = document.getElementById("slots");
    box.innerHTML = "";
    d.slots.forEach(s => {
      box.innerHTML += `<div class="slot ${s.status}">Slot ${s.slotNumber}<small>${s.status}</small></div>`;
    });
  } catch (e) {
    showMessage("entryMsg", "Cannot reach the Java server. Is it running on port 8080?", false);
  }
}

// ---------- VEHICLE ENTRY ----------
async function enterVehicle() {
  try {
    const res = await post("/entry", {
      carNumber: val("carNumber"),
      driverName: val("driverName"),
      vehicleType: val("vehicleType"),
      entryTime: val("entryTime")
    });
    showMessage("entryMsg", res.message, res.success);
    loadDashboard();
  } catch (e) {
    showMessage("entryMsg", "Cannot reach the Java server.", false);
  }
}

// ---------- VEHICLE EXIT: step 1 (show the bill) ----------
async function searchVehicle() {
  const bill = document.getElementById("bill");
  const confirmBtn = document.getElementById("confirmBtn");
  try {
    const r = await post("/exit/preview", { carNumber: val("searchCar"), exitTime: val("exitTime") });
    if (!r.success) {
      bill.style.display = "none";
      confirmBtn.style.display = "none";
      showMessage("exitMsg", r.message, false);
      return;
    }
    showMessage("exitMsg", "", true);
    const rows = [
      ["Car Number", r.carNumber],
      ["Parking Slot", "Slot " + r.slot],
      ["Entry Time", r.entryTime],
      ["Exit Time", r.exitTime],
      ["Total Parking Duration", r.totalDuration],
      ["Allowed Duration", r.allowedDuration],
      ["Extra Duration", r.extraDuration],
      ["Normal Charge", "₹" + r.normalCharge],
      ["Extra Charge", "₹" + r.extraCharge],
      ["Total Charge", "₹" + r.totalCharge]
    ];
    bill.innerHTML = "";
    rows.forEach(([label, value]) => {
      const tr = document.createElement("tr");
      if (label === "Total Charge") tr.className = "total";
      const a = document.createElement("td"); a.textContent = label;
      const b = document.createElement("td"); b.textContent = value;
      tr.append(a, b);
      bill.appendChild(tr);
    });
    bill.style.display = "table";
    confirmBtn.style.display = "inline-block";
  } catch (e) {
    showMessage("exitMsg", "Cannot reach the Java server.", false);
  }
}

// ---------- VEHICLE EXIT: step 2 (confirm, save, free the slot) ----------
async function confirmExit() {
  try {
    const r = await post("/exit/confirm", { carNumber: val("searchCar"), exitTime: val("exitTime") });
    showMessage("exitMsg",
      r.success ? `Exit complete. Collect ₹${r.totalCharge} from ${r.carNumber}. Slot ${r.slot} is free again.` : r.message,
      r.success);
    document.getElementById("bill").style.display = "none";
    document.getElementById("confirmBtn").style.display = "none";
    loadDashboard();
  } catch (e) {
    showMessage("exitMsg", "Cannot reach the Java server.", false);
  }
}

loadDashboard();
setInterval(loadDashboard, 15000);   // refresh the dashboard every 15 seconds
