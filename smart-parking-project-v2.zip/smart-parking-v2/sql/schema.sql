CREATE DATABASE IF NOT EXISTS smart_parking;
USE smart_parking;

-- Physical parking slots
CREATE TABLE parking_slots (
    slot_id     INT AUTO_INCREMENT PRIMARY KEY,
    slot_number INT NOT NULL UNIQUE,
    status      VARCHAR(10) NOT NULL DEFAULT 'AVAILABLE'      -- AVAILABLE / OCCUPIED
);

-- Vehicle details (one row per car number)
CREATE TABLE vehicles (
    vehicle_id   INT AUTO_INCREMENT PRIMARY KEY,
    car_number   VARCHAR(20) NOT NULL UNIQUE,
    driver_name  VARCHAR(50) NOT NULL,
    vehicle_type VARCHAR(20) NOT NULL
);

-- One row per parking visit
CREATE TABLE parking_records (
    record_id        INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id       INT NOT NULL,
    slot_id          INT NOT NULL,
    entry_time       DATETIME NOT NULL,
    exit_time        DATETIME NULL,
    allowed_minutes  INT NOT NULL,
    total_minutes    INT NULL,
    extra_minutes    INT NULL,
    normal_charge    INT NULL,
    extra_charge     INT NULL,
    total_charge     INT NULL,
    status           VARCHAR(10) NOT NULL DEFAULT 'ACTIVE',   -- ACTIVE / COMPLETED
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id),
    FOREIGN KEY (slot_id)    REFERENCES parking_slots(slot_id)
);

-- One payment per completed visit
CREATE TABLE payments (
    payment_id     INT AUTO_INCREMENT PRIMARY KEY,
    record_id      INT NOT NULL,
    amount         INT NOT NULL,
    payment_status VARCHAR(10) NOT NULL DEFAULT 'PAID',       -- PAID / PENDING
    payment_time   DATETIME NOT NULL,
    FOREIGN KEY (record_id) REFERENCES parking_records(record_id)
);

-- ---------- Sample data ----------
INSERT INTO parking_slots (slot_number) VALUES (1),(2),(3),(4),(5),(6),(7),(8);

INSERT INTO vehicles (car_number, driver_name, vehicle_type) VALUES
('DL01AB1234', 'Rahul Sharma', 'Car'),
('MH12XY9876', 'Priya Singh',  'Car'),
('KA03MN4455', 'Amit Verma',   'Truck');

-- Two old, completed visits so history queries return something
INSERT INTO parking_records
 (vehicle_id, slot_id, entry_time, exit_time, allowed_minutes, total_minutes, extra_minutes,
  normal_charge, extra_charge, total_charge, status) VALUES
 (1, 1, '2026-09-30 10:00:00', '2026-09-30 11:30:00', 120,  90,   0, 50,  0,  50, 'COMPLETED'),
 (2, 2, '2026-09-30 09:00:00', '2026-09-30 14:00:00', 120, 300, 180, 50, 60, 110, 'COMPLETED');

INSERT INTO payments (record_id, amount, payment_status, payment_time) VALUES
 (1,  50, 'PAID', '2026-09-30 11:30:00'),
 (2, 110, 'PAID', '2026-09-30 14:00:00');
