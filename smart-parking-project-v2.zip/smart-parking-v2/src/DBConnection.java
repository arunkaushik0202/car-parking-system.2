import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

// Gives us a connection to MySQL. Change USER / PASSWORD to yours.
public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/smart_parking";
    private static final String USER = "root";
    private static final String PASSWORD = "your_password";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
