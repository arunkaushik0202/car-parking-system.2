// Tiny helper to build JSON text by hand (so we need no library).
public class JsonUtil {
    // Wraps text in quotes and escapes characters that would break JSON.
    public static String quote(String text) {
        if (text == null) return "null";
        return "\"" + text.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }
}
