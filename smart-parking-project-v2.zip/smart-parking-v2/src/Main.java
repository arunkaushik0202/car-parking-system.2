import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

// Starts the web server (JDK built-in, no framework) and maps each URL to a controller method.
public class Main {

    // One request handler: gets the request parameters, returns a JSON string.
    interface Action { String run(Map<String, String> params) throws Exception; }

    public static void main(String[] args) throws Exception {
        ParkingConfig config = new ParkingConfig("config.properties");
        ParkingService service = new ParkingService(config);
        ParkingController controller = new ParkingController(service);

        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        server.createContext("/api/dashboard",    ex -> handle(ex, p -> controller.getDashboard()));
        server.createContext("/api/entry",        ex -> handle(ex, controller::parkVehicle));
        server.createContext("/api/exit/preview", ex -> handle(ex, controller::previewExit));
        server.createContext("/api/exit/confirm", ex -> handle(ex, controller::confirmExit));
        server.start();
        System.out.println("Server running at http://localhost:8080");
    }

    // Common wrapper: CORS headers, read parameters, run the action, turn errors into JSON.
    static void handle(HttpExchange ex, Action action) throws IOException {
        ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");   // lets index.html call us
        ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
        ex.getResponseHeaders().add("Content-Type", "application/json");
        if (ex.getRequestMethod().equals("OPTIONS")) { send(ex, 204, ""); return; }
        try {
            send(ex, 200, action.run(readParams(ex)));
        } catch (ParkingException e) {                 // expected business errors (Parking Full ...)
            send(ex, 200, "{\"success\":false,\"message\":" + JsonUtil.quote(e.getMessage()) + "}");
        } catch (Exception e) {                        // unexpected problems (database down ...)
            e.printStackTrace();
            send(ex, 500, "{\"success\":false,\"message\":\"Server error\"}");
        }
    }

    static void send(HttpExchange ex, int code, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(code, bytes.length == 0 ? -1 : bytes.length);
        if (bytes.length > 0) ex.getResponseBody().write(bytes);
        ex.close();
    }

    // Reads key=value&key=value from the POST body (or the URL for GET).
    static Map<String, String> readParams(HttpExchange ex) throws IOException {
        String raw = ex.getRequestMethod().equals("POST")
                ? new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8)
                : ex.getRequestURI().getRawQuery();
        Map<String, String> map = new HashMap<>();
        if (raw == null) return map;
        for (String pair : raw.split("&")) {
            String[] kv = pair.split("=", 2);
            if (kv.length == 2) {
                map.put(URLDecoder.decode(kv[0], StandardCharsets.UTF_8),
                        URLDecoder.decode(kv[1], StandardCharsets.UTF_8));
            }
        }
        return map;
    }
}
