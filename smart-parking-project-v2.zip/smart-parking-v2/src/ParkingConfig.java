import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

// Holds the configurable parking rules. Values come from config.properties,
// so the owner can change prices without touching the code.
public class ParkingConfig {
    private int allowedHours = 2;        // default: 2 hours covered by the base charge
    private int baseCharge = 50;         // default: Rs.50 for the allowed period
    private int extraRatePerHour = 20;   // default: Rs.20 for every extra hour

    public ParkingConfig(String fileName) {
        Properties props = new Properties();
        try (FileInputStream in = new FileInputStream(fileName)) {
            props.load(in);
            allowedHours = Integer.parseInt(props.getProperty("allowed.hours", "2").trim());
            baseCharge = Integer.parseInt(props.getProperty("base.charge", "50").trim());
            extraRatePerHour = Integer.parseInt(props.getProperty("extra.rate.per.hour", "20").trim());
        } catch (IOException | NumberFormatException e) {
            System.out.println("Could not read " + fileName + " - using default rates");
        }
    }

    public int getAllowedHours() { return allowedHours; }
    public int getBaseCharge() { return baseCharge; }
    public int getExtraRatePerHour() { return extraRatePerHour; }
    public long getAllowedMinutes() { return allowedHours * 60L; }
}
