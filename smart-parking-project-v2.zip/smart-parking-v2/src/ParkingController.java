import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Map;

// The Controller receives the request parameters from the frontend, calls ParkingService,
// and turns the result into JSON. It contains NO business rules.
public class ParkingController {
    private final ParkingService service;
    private static final DateTimeFormatter SHOW = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public ParkingController(ParkingService service) {
        this.service = service;
    }

    // GET /api/dashboard
    public String getDashboard() throws SQLException {
        StringBuilder slotsJson = new StringBuilder("[");
        for (ParkingSlot slot : service.getSlots()) {
            if (slotsJson.length() > 1) slotsJson.append(",");
            slotsJson.append("{\"slotNumber\":").append(slot.getSlotNumber())
                     .append(",\"status\":").append(JsonUtil.quote(slot.getStatus())).append("}");
        }
        slotsJson.append("]");

        int total = service.getSlots().size();
        int available = service.getAvailableCount();
        ParkingConfig cfg = service.getConfig();

        return "{\"success\":true"
             + ",\"totalSlots\":" + total
             + ",\"availableSlots\":" + available
             + ",\"occupiedSlots\":" + (total - available)
             + ",\"totalVehicles\":" + service.getTotalVehiclesToday()
             + ",\"todayRevenue\":" + service.getTodayRevenue()
             + ",\"allowedHours\":" + cfg.getAllowedHours()
             + ",\"baseCharge\":" + cfg.getBaseCharge()
             + ",\"extraRate\":" + cfg.getExtraRatePerHour()
             + ",\"slots\":" + slotsJson + "}";
    }

    // POST /api/entry
    public String parkVehicle(Map<String, String> p) throws SQLException {
        ParkingRecord r = service.parkVehicle(value(p, "carNumber"), value(p, "driverName"),
                value(p, "vehicleType"), parseTime(value(p, "entryTime")));
        String message = "Vehicle " + r.getVehicle().getCarNumber() + " parked in Slot "
                + r.getParkingSlot().getSlotNumber() + ". Allowed time: "
                + ParkingService.formatDuration(r.getAllowedDuration());
        return "{\"success\":true,\"message\":" + JsonUtil.quote(message) + "}";
    }

    // POST /api/exit/preview  -> bill, nothing saved
    public String previewExit(Map<String, String> p) throws SQLException {
        return billJson(service.previewExit(value(p, "carNumber"), parseTime(value(p, "exitTime"))));
    }

    // POST /api/exit/confirm  -> bill, saved, slot released
    public String confirmExit(Map<String, String> p) throws SQLException {
        return billJson(service.exitVehicle(value(p, "carNumber"), parseTime(value(p, "exitTime"))));
    }

    // ---------- helpers ----------

    private String value(Map<String, String> p, String key) {
        String v = p.get(key);
        return v == null ? "" : v.trim();
    }

    // "" -> null (service uses the current time), otherwise parse "2026-10-03T10:00"
    private LocalDateTime parseTime(String text) {
        if (text.isEmpty()) return null;
        try {
            return LocalDateTime.parse(text);
        } catch (DateTimeParseException e) {
            throw new ParkingException("Invalid parking time format");
        }
    }

    private String billJson(ParkingRecord r) {
        return "{\"success\":true"
             + ",\"carNumber\":" + JsonUtil.quote(r.getVehicle().getCarNumber())
             + ",\"driverName\":" + JsonUtil.quote(r.getVehicle().getDriverName())
             + ",\"slot\":" + r.getParkingSlot().getSlotNumber()
             + ",\"entryTime\":" + JsonUtil.quote(r.getEntryTime().format(SHOW))
             + ",\"exitTime\":" + JsonUtil.quote(r.getExitTime().format(SHOW))
             + ",\"totalDuration\":" + JsonUtil.quote(ParkingService.formatDuration(r.getTotalDuration()))
             + ",\"allowedDuration\":" + JsonUtil.quote(ParkingService.formatDuration(r.getAllowedDuration()))
             + ",\"extraDuration\":" + JsonUtil.quote(ParkingService.formatDuration(r.getExtraDuration()))
             + ",\"normalCharge\":" + r.getNormalCharge()
             + ",\"extraCharge\":" + r.getExtraCharge()
             + ",\"totalCharge\":" + r.getTotalCharge() + "}";
    }
}
