import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

// DAO = Data Access Object. ONLY this class talks to MySQL (via JDBC).
// Methods that change several tables use a TRANSACTION: either everything is saved, or nothing.
public class ParkingDAO {

    // ---------- READ ----------

    public List<ParkingSlot> getAllSlots() throws SQLException {
        List<ParkingSlot> list = new ArrayList<>();
        String sql = "SELECT slot_id, slot_number, status FROM parking_slots ORDER BY slot_number";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new ParkingSlot(rs.getInt("slot_id"), rs.getInt("slot_number"), rs.getString("status")));
            }
        }
        return list;
    }

    // Vehicles that are parked right now (status = ACTIVE)
    public List<ParkingRecord> getActiveRecords(List<ParkingSlot> slots) throws SQLException {
        List<ParkingRecord> list = new ArrayList<>();
        String sql = "SELECT r.record_id, r.slot_id, r.entry_time, r.allowed_minutes, "
                   + "v.vehicle_id, v.car_number, v.driver_name, v.vehicle_type "
                   + "FROM parking_records r JOIN vehicles v ON r.vehicle_id = v.vehicle_id "
                   + "WHERE r.status = 'ACTIVE'";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Vehicle v = new Vehicle(rs.getInt("vehicle_id"), rs.getString("car_number"),
                        rs.getString("driver_name"), rs.getString("vehicle_type"));
                ParkingSlot slot = null;
                for (ParkingSlot s : slots) {
                    if (s.getSlotId() == rs.getInt("slot_id")) slot = s;
                }
                list.add(new ParkingRecord(rs.getInt("record_id"), v, slot,
                        rs.getTimestamp("entry_time").toLocalDateTime(), rs.getInt("allowed_minutes")));
            }
        }
        return list;
    }

    // Has this car parked before and already left?
    public boolean hasCompletedRecord(String carNumber) throws SQLException {
        String sql = "SELECT COUNT(*) FROM parking_records r JOIN vehicles v ON r.vehicle_id = v.vehicle_id "
                   + "WHERE v.car_number = ? AND r.status = 'COMPLETED'";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, carNumber);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }

    // Dashboard: vehicles that entered today
    public int countVehiclesToday() throws SQLException {
        return singleNumber("SELECT COUNT(*) FROM parking_records WHERE DATE(entry_time) = CURDATE()");
    }

    // Dashboard: money received today
    public int revenueToday() throws SQLException {
        return singleNumber("SELECT COALESCE(SUM(amount), 0) FROM payments "
                          + "WHERE payment_status = 'PAID' AND DATE(payment_time) = CURDATE()");
    }

    private int singleNumber(String sql) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        }
    }

    // ---------- WRITE (transactions) ----------

    // ENTRY: save vehicle + create ACTIVE record + mark slot OCCUPIED, all in ONE transaction.
    // Returns {vehicleId, recordId}.
    public int[] saveEntry(String carNumber, String driverName, String vehicleType,
                           int slotId, LocalDateTime entry, long allowedMinutes) throws SQLException {
        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);                       // start transaction
            try {
                int vehicleId = findOrCreateVehicle(c, carNumber, driverName, vehicleType);
                int recordId = insertRecord(c, vehicleId, slotId, entry, allowedMinutes);
                updateSlotStatus(c, slotId, ParkingSlot.OCCUPIED);
                c.commit();                               // all 3 steps succeeded
                return new int[]{vehicleId, recordId};
            } catch (SQLException e) {
                c.rollback();                             // something failed: undo everything
                throw e;
            }
        }
    }

    // EXIT: complete the record + free the slot + save the payment, all in ONE transaction.
    public void completeExit(ParkingRecord r) throws SQLException {
        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                String sql = "UPDATE parking_records SET exit_time=?, total_minutes=?, extra_minutes=?, "
                           + "normal_charge=?, extra_charge=?, total_charge=?, status='COMPLETED' WHERE record_id=?";
                try (PreparedStatement ps = c.prepareStatement(sql)) {
                    ps.setTimestamp(1, Timestamp.valueOf(r.getExitTime()));
                    ps.setLong(2, r.getTotalDuration());
                    ps.setLong(3, r.getExtraDuration());
                    ps.setInt(4, r.getNormalCharge());
                    ps.setInt(5, r.getExtraCharge());
                    ps.setInt(6, r.getTotalCharge());
                    ps.setInt(7, r.getRecordId());
                    ps.executeUpdate();
                }
                updateSlotStatus(c, r.getParkingSlot().getSlotId(), ParkingSlot.AVAILABLE);

                String paySql = "INSERT INTO payments (record_id, amount, payment_status, payment_time) "
                              + "VALUES (?, ?, 'PAID', ?)";
                try (PreparedStatement ps = c.prepareStatement(paySql)) {
                    ps.setInt(1, r.getRecordId());
                    ps.setInt(2, r.getTotalCharge());
                    ps.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
                    ps.executeUpdate();
                }
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    // ---------- small helpers that reuse the SAME connection (needed for transactions) ----------

    private int findOrCreateVehicle(Connection c, String carNumber, String driverName, String type)
            throws SQLException {
        try (PreparedStatement find = c.prepareStatement("SELECT vehicle_id FROM vehicles WHERE car_number = ?")) {
            find.setString(1, carNumber);
            try (ResultSet rs = find.executeQuery()) {
                if (rs.next()) {                          // known car: refresh driver/type, reuse id
                    int id = rs.getInt(1);
                    try (PreparedStatement up = c.prepareStatement(
                            "UPDATE vehicles SET driver_name = ?, vehicle_type = ? WHERE vehicle_id = ?")) {
                        up.setString(1, driverName);
                        up.setString(2, type);
                        up.setInt(3, id);
                        up.executeUpdate();
                    }
                    return id;
                }
            }
        }
        try (PreparedStatement ins = c.prepareStatement(
                "INSERT INTO vehicles (car_number, driver_name, vehicle_type) VALUES (?,?,?)",
                Statement.RETURN_GENERATED_KEYS)) {
            ins.setString(1, carNumber);
            ins.setString(2, driverName);
            ins.setString(3, type);
            ins.executeUpdate();
            try (ResultSet keys = ins.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        }
    }

    private int insertRecord(Connection c, int vehicleId, int slotId, LocalDateTime entry, long allowed)
            throws SQLException {
        String sql = "INSERT INTO parking_records (vehicle_id, slot_id, entry_time, allowed_minutes) VALUES (?,?,?,?)";
        try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, vehicleId);
            ps.setInt(2, slotId);
            ps.setTimestamp(3, Timestamp.valueOf(entry));
            ps.setLong(4, allowed);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        }
    }

    private void updateSlotStatus(Connection c, int slotId, String status) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("UPDATE parking_slots SET status = ? WHERE slot_id = ?")) {
            ps.setString(1, status);
            ps.setInt(2, slotId);
            ps.executeUpdate();
        }
    }
}
