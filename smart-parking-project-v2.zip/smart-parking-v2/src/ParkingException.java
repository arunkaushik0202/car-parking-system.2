// Our own exception for BUSINESS errors (Parking Full, Vehicle not found, invalid input...).
// It EXTENDS RuntimeException - this is the one place inheritance really makes sense:
// a ParkingException "is a" RuntimeException, so we don't need to declare it on every method.
public class ParkingException extends RuntimeException {
    public ParkingException(String message) {
        super(message);
    }
}
