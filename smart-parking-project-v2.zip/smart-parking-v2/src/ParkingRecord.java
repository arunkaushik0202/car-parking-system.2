import java.time.LocalDateTime;

// One parking visit. It HAS-A Vehicle and HAS-A ParkingSlot (composition).
// Durations are stored in MINUTES (a whole number is easy to calculate with).
public class ParkingRecord {
    public static final String ACTIVE = "ACTIVE";
    public static final String COMPLETED = "COMPLETED";

    private int recordId;
    private Vehicle vehicle;
    private ParkingSlot parkingSlot;
    private LocalDateTime entryTime;
    private LocalDateTime exitTime;      // null until the vehicle exits
    private long allowedDuration;        // minutes covered by the normal charge
    private long totalDuration;          // minutes actually parked
    private long extraDuration;          // minutes beyond the allowed time
    private int normalCharge;
    private int extraCharge;
    private int totalCharge;
    private String status = ACTIVE;

    public ParkingRecord(int recordId, Vehicle vehicle, ParkingSlot parkingSlot,
                         LocalDateTime entryTime, long allowedDuration) {
        this.recordId = recordId;
        this.vehicle = vehicle;
        this.parkingSlot = parkingSlot;
        this.entryTime = entryTime;
        this.allowedDuration = allowedDuration;
    }

    public int getRecordId() { return recordId; }
    public Vehicle getVehicle() { return vehicle; }
    public ParkingSlot getParkingSlot() { return parkingSlot; }
    public LocalDateTime getEntryTime() { return entryTime; }
    public LocalDateTime getExitTime() { return exitTime; }
    public long getAllowedDuration() { return allowedDuration; }
    public long getTotalDuration() { return totalDuration; }
    public long getExtraDuration() { return extraDuration; }
    public int getNormalCharge() { return normalCharge; }
    public int getExtraCharge() { return extraCharge; }
    public int getTotalCharge() { return totalCharge; }
    public String getStatus() { return status; }

    public void setExitTime(LocalDateTime exitTime) { this.exitTime = exitTime; }
    public void setTotalDuration(long totalDuration) { this.totalDuration = totalDuration; }
    public void setExtraDuration(long extraDuration) { this.extraDuration = extraDuration; }
    public void setNormalCharge(int normalCharge) { this.normalCharge = normalCharge; }
    public void setExtraCharge(int extraCharge) { this.extraCharge = extraCharge; }
    public void setTotalCharge(int totalCharge) { this.totalCharge = totalCharge; }
    public void setStatus(String status) { this.status = status; }
}
