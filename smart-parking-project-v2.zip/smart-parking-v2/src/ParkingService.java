import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// ALL business logic lives here: slot checking, parking, search, time and charge calculation, exit.
public class ParkingService {
    private final ParkingDAO dao = new ParkingDAO();
    private final ParkingConfig config;

    // ArrayList: keeps all slots in order, so we can loop and pick the first free one.
    private final List<ParkingSlot> slots;

    // HashMap: carNumber -> active ParkingRecord. Finds a parked car in O(1) without looping.
    private final Map<String, ParkingRecord> activeRecords = new HashMap<>();

    private static final List<String> VEHICLE_TYPES = Arrays.asList("Car", "Bike", "Truck");

    // On startup load the current state from MySQL, so a server restart loses nothing.
    public ParkingService(ParkingConfig config) throws SQLException {
        this.config = config;
        this.slots = dao.getAllSlots();
        for (ParkingRecord r : dao.getActiveRecords(slots)) {
            activeRecords.put(r.getVehicle().getCarNumber(), r);
        }
    }

    // ================= SLOT CHECKING =================

    // Returns the first AVAILABLE slot, or null when the parking is full.
    public ParkingSlot checkAvailableSlot() {
        for (ParkingSlot slot : slots) {
            if (slot.isAvailable()) return slot;
        }
        return null;
    }

    public int getAvailableCount() {
        int count = 0;
        for (ParkingSlot slot : slots) {
            if (slot.isAvailable()) count++;
        }
        return count;
    }

    // ================= VEHICLE ENTRY =================

    // synchronized: only one request at a time, so two cars can never get the same slot.
    public synchronized ParkingRecord parkVehicle(String carNumber, String driverName,
                                                  String vehicleType, LocalDateTime entryTime) throws SQLException {
        carNumber = normalizeCarNumber(carNumber);
        validateVehicleInfo(carNumber, driverName, vehicleType);

        LocalDateTime now = LocalDateTime.now();
        if (entryTime == null) entryTime = now;                       // blank = current time
        if (entryTime.isAfter(now.plusMinutes(1))) {
            throw new ParkingException("Invalid parking time: entry time cannot be in the future");
        }
        if (activeRecords.containsKey(carNumber)) {
            throw new ParkingException("Vehicle " + carNumber + " is already parked");
        }

        ParkingSlot slot = checkAvailableSlot();
        if (slot == null) {
            throw new ParkingException("Parking Full - No Slot Available");
        }

        // Save to MySQL first. If this fails, memory is untouched and stays correct.
        int[] ids = dao.saveEntry(carNumber, driverName.trim(), vehicleType,
                slot.getSlotId(), entryTime, config.getAllowedMinutes());

        slot.setStatus(ParkingSlot.OCCUPIED);
        Vehicle vehicle = new Vehicle(ids[0], carNumber, driverName.trim(), vehicleType);
        ParkingRecord record = new ParkingRecord(ids[1], vehicle, slot, entryTime, config.getAllowedMinutes());
        activeRecords.put(carNumber, record);
        return record;
    }

    private String normalizeCarNumber(String carNumber) {
        if (carNumber == null) return "";
        return carNumber.replaceAll("\\s", "").toUpperCase();         // "dl 01 ab 1234" -> "DL01AB1234"
    }

    private void validateVehicleInfo(String carNumber, String driverName, String vehicleType) {
        if (carNumber.isEmpty()) {
            throw new ParkingException("Car number cannot be empty");
        }
        if (!carNumber.matches("[A-Z0-9]{6,12}")) {
            throw new ParkingException("Invalid car number (use 6-12 letters/digits, e.g. DL01AB1234)");
        }
        if (driverName == null || !driverName.trim().matches("[A-Za-z .]{2,50}")) {
            throw new ParkingException("Invalid driver name (2-50 letters)");
        }
        if (vehicleType == null || !VEHICLE_TYPES.contains(vehicleType)) {
            throw new ParkingException("Invalid vehicle type (choose Car, Bike or Truck)");
        }
    }

    // ================= VEHICLE SEARCH =================

    // Finds a currently parked vehicle by car number.
    public ParkingRecord findVehicle(String carNumber) throws SQLException {
        carNumber = normalizeCarNumber(carNumber);
        if (carNumber.isEmpty()) {
            throw new ParkingException("Car number cannot be empty");
        }
        ParkingRecord record = activeRecords.get(carNumber);          // fast HashMap lookup
        if (record != null) return record;

        // Not parked now: did it park before and already leave?
        if (dao.hasCompletedRecord(carNumber)) {
            throw new ParkingException("Vehicle has already exited");
        }
        throw new ParkingException("Vehicle not found");
    }

    // ================= TIME AND CHARGE CALCULATION =================

    // Minutes between entry and exit. Never negative.
    public static long calculateParkingDuration(LocalDateTime entry, LocalDateTime exit) {
        return Math.max(0, Duration.between(entry, exit).toMinutes());
    }

    // NORMAL charge: a fixed fee that covers the allowed time (e.g. Rs.50 for 2 hours).
    // Even a 10-minute stay pays it.
    public int calculateParkingCharge(long totalMinutes) {
        return config.getBaseCharge();
    }

    // EXTRA charge: every started extra hour costs the extra rate (partial hour = full hour).
    public int calculateExtraCharge(long extraMinutes) {
        long extraHours = (extraMinutes + 59) / 60;                   // round UP: 150 min -> 3 hours
        return (int) (extraHours * config.getExtraRatePerHour());
    }

    // Fills the duration and charge fields of a record. Does NOT save anything.
    private void calculateBill(ParkingRecord record, LocalDateTime exitTime) {
        if (exitTime == null) exitTime = LocalDateTime.now();
        if (exitTime.isBefore(record.getEntryTime())) {
            throw new ParkingException("Invalid parking time: exit time is before entry time");
        }
        long total = calculateParkingDuration(record.getEntryTime(), exitTime);
        long extra = Math.max(0, total - record.getAllowedDuration());
        int normalCharge = calculateParkingCharge(total);
        int extraCharge = calculateExtraCharge(extra);

        record.setExitTime(exitTime);
        record.setTotalDuration(total);
        record.setExtraDuration(extra);
        record.setNormalCharge(normalCharge);
        record.setExtraCharge(extraCharge);
        record.setTotalCharge(normalCharge + extraCharge);
    }

    // ================= VEHICLE EXIT =================

    // Step 1: show the bill. Nothing is saved, the slot stays OCCUPIED.
    public synchronized ParkingRecord previewExit(String carNumber, LocalDateTime exitTime) throws SQLException {
        ParkingRecord record = findVehicle(carNumber);
        calculateBill(record, exitTime);
        return record;
    }

    // Step 2: confirm. Recalculate, save to MySQL, free the slot.
    public synchronized ParkingRecord exitVehicle(String carNumber, LocalDateTime exitTime) throws SQLException {
        ParkingRecord record = findVehicle(carNumber);
        calculateBill(record, exitTime);

        dao.completeExit(record);                                     // record + slot + payment (one transaction)

        releaseSlot(record.getParkingSlot());
        record.setStatus(ParkingRecord.COMPLETED);
        activeRecords.remove(record.getVehicle().getCarNumber());     // no longer parked
        return record;
    }

    // Makes the slot AVAILABLE again in memory (MySQL was already updated inside completeExit).
    private void releaseSlot(ParkingSlot slot) {
        slot.setStatus(ParkingSlot.AVAILABLE);
    }

    // ================= DASHBOARD DATA =================

    public List<ParkingSlot> getSlots() { return slots; }
    public ParkingConfig getConfig() { return config; }
    public int getTotalVehiclesToday() throws SQLException { return dao.countVehiclesToday(); }
    public int getTodayRevenue() throws SQLException { return dao.revenueToday(); }

    // 210 -> "3 hr 30 min"
    public static String formatDuration(long minutes) {
        return (minutes / 60) + " hr " + (minutes % 60) + " min";
    }
}
