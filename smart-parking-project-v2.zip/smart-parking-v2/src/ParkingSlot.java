// One parking slot. Status is either AVAILABLE or OCCUPIED.
public class ParkingSlot {
    public static final String AVAILABLE = "AVAILABLE";
    public static final String OCCUPIED = "OCCUPIED";

    private int slotId;        // database id
    private int slotNumber;    // number shown to the user (Slot 1, Slot 2 ...)
    private String status;

    public ParkingSlot(int slotId, int slotNumber, String status) {
        this.slotId = slotId;
        this.slotNumber = slotNumber;
        this.status = status;
    }

    public int getSlotId() { return slotId; }
    public int getSlotNumber() { return slotNumber; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public boolean isAvailable() { return AVAILABLE.equals(status); }
}
