// Holds vehicle details. Fields are private (encapsulation); we read them through getters.
public class Vehicle {
    private int vehicleId;
    private String carNumber;
    private String driverName;
    private String vehicleType;

    public Vehicle(int vehicleId, String carNumber, String driverName, String vehicleType) {
        this.vehicleId = vehicleId;
        this.carNumber = carNumber;
        this.driverName = driverName;
        this.vehicleType = vehicleType;
    }

    public int getVehicleId() { return vehicleId; }
    public String getCarNumber() { return carNumber; }
    public String getDriverName() { return driverName; }
    public String getVehicleType() { return vehicleType; }
}
